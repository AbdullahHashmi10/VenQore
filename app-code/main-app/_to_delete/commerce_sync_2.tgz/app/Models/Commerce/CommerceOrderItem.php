<?php

namespace App\Models\Commerce;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

class CommerceOrderItem extends Model
{
    use HasUuids;

    protected $table = 'commerce_order_items';
    protected $guarded = [];
    protected $casts = ['price_includes_tax' => 'boolean'];
}
