import React from 'react';
import { Link } from '@inertiajs/react';

/** Minimal shopper shell: no merchant navigation, no account chrome. */
export default function PublicShell({ children, title }) {
    return (
        <div className="min-h-screen bg-app text-ink">
            <header className="border-b border-line bg-surface">
                <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
                    <Link href="/shop" className="font-bold text-ink">VenQore Shop</Link>
                    {title && <span className="text-sm text-ink-muted truncate ml-4">{title}</span>}
                </div>
            </header>
            <main className="max-w-5xl mx-auto px-4 py-6">{children}</main>
            <footer className="max-w-5xl mx-auto px-4 py-8 text-xs text-ink-muted">
                Orders are requests to the business and are confirmed by them. Prices and availability are set by each business.
            </footer>
        </div>
    );
}
