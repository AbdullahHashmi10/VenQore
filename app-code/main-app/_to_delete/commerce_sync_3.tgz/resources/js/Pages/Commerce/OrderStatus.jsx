import React, { useState } from 'react';
import { Head, router, usePage } from '@inertiajs/react';
import PublicShell from '@/Components/Commerce/PublicShell';
import { Alert, Button, Card, Field, inputCls, Pill } from '@/Components/Commerce/ui';
import { METHOD_LABEL, PAYMENT_LABEL, STATUS_LABEL, STATUS_TONE, money } from '@/lib/commerce';

const STEPS_PICKUP = ['pending', 'confirmed', 'preparing', 'ready', 'completed'];
const STEPS_DELIVERY = ['pending', 'confirmed', 'preparing', 'out_for_delivery', 'completed'];

export default function OrderStatus({ order, store, events, transfer_url }) {
    const { flash, errors } = usePage().props;
    const [ref, setRef] = useState('');
    const sym = order.currency_symbol;
    const steps = order.fulfilment === 'delivery' ? STEPS_DELIVERY : STEPS_PICKUP;
    const closed = ['rejected', 'cancelled', 'expired'].includes(order.status);
    const idx = steps.indexOf(order.status);

    return (
        <PublicShell title={store.name}>
            <Head title={`Order ${order.number}`}>
                <meta name="robots" content="noindex,nofollow,noarchive" />
            </Head>

            <div className="flex flex-wrap items-center gap-3">
                <h1 className="text-2xl font-bold">Order {order.number}</h1>
                <Pill tone={STATUS_TONE[order.status]}>{STATUS_LABEL[order.status]}</Pill>
            </div>
            <p className="text-sm text-ink-muted mt-1">Placed {order.placed_at}. Save this page&apos;s link — it is the only way to follow this order.</p>

            {flash?.success && <div className="mt-4"><Alert kind="success">{flash.success}</Alert></div>}

            {order.status === 'pending' && (
                <div className="mt-4"><Alert kind="info">Your order is a request. {store.name} must confirm that the items are available before it is accepted.</Alert></div>
            )}
            {closed && <div className="mt-4"><Alert kind="error">This order was {order.status === 'expired' ? 'not accepted in time' : order.status}.{order.reason ? ` Reason: ${order.reason}` : ''} You have not been charged.</Alert></div>}

            {!closed && (
                <ol className="mt-6 grid grid-cols-5 gap-2" aria-label="Order progress">
                    {steps.map((s, i) => (
                        <li key={s} className={`rounded-xl px-2 py-2 text-center text-xs font-medium ${i <= idx ? 'bg-brand-600 text-white' : 'bg-sunken text-ink-muted'}`} aria-current={i === idx ? 'step' : undefined}>
                            {STATUS_LABEL[s]}
                        </li>
                    ))}
                </ol>
            )}

            <div className="grid md:grid-cols-3 gap-4 mt-6">
                <Card className="md:col-span-2">
                    <h2 className="font-semibold mb-3">Items</h2>
                    <ul className="divide-y divide-line">
                        {order.items.map((i, k) => (
                            <li key={k} className="py-2 flex justify-between gap-3 text-sm">
                                <span>{Number(i.quantity)} × {i.title}</span>
                                <span className="tabular-nums">{money(i.line_total, sym)}</span>
                            </li>
                        ))}
                    </ul>
                    <dl className="mt-3 text-sm space-y-1">
                        <div className="flex justify-between"><dt className="text-ink-muted">Subtotal</dt><dd className="tabular-nums">{money(order.subtotal, sym)}</dd></div>
                        {Number(order.tax_total) > 0 && <div className="flex justify-between"><dt className="text-ink-muted">Tax</dt><dd className="tabular-nums">{money(order.tax_total, sym)}</dd></div>}
                        {Number(order.delivery_fee) > 0 && <div className="flex justify-between"><dt className="text-ink-muted">Delivery</dt><dd className="tabular-nums">{money(order.delivery_fee, sym)}</dd></div>}
                        <div className="flex justify-between font-bold text-base border-t border-line pt-2"><dt>Total</dt><dd className="tabular-nums">{money(order.total, sym)}</dd></div>
                    </dl>
                </Card>

                <div className="space-y-4">
                    <Card>
                        <h2 className="font-semibold mb-2">{order.fulfilment === 'delivery' ? 'Delivery' : 'Pickup'}</h2>
                        {order.fulfilment === 'delivery' && <p className="text-sm whitespace-pre-line">{order.delivery_address}</p>}
                        <p className="text-sm text-ink-muted mt-2">{METHOD_LABEL[order.payment_method]} · {PAYMENT_LABEL[order.payment_status]}</p>
                    </Card>
                    <Card>
                        <h2 className="font-semibold mb-2">{store.name}</h2>
                        {store.address && <p className="text-sm">{store.address}</p>}
                        {store.phone && <p className="text-sm mt-1"><a className="underline" href={`tel:${store.phone}`}>{store.phone}</a></p>}
                    </Card>
                </div>
            </div>

            {store.bank_instructions && order.payment_method === 'bank' && !closed && (
                <Card className="mt-4">
                    <h2 className="font-semibold mb-2">Bank transfer</h2>
                    <p className="text-sm whitespace-pre-line">{store.bank_instructions}</p>
                    {order.payment_status === 'unpaid' ? (
                        <form className="mt-4 flex flex-wrap items-end gap-3" onSubmit={(e) => { e.preventDefault(); router.post(transfer_url, { reference: ref }, { preserveScroll: true }); }}>
                            <Field label="Transfer reference" error={errors?.reference} className="flex-1 min-w-48">
                                <input className={inputCls} value={ref} onChange={(e) => setRef(e.target.value)} placeholder="Transaction ID / reference" required minLength={3} maxLength={120} />
                            </Field>
                            <Button type="submit" onClick={() => {}}>I have sent the transfer</Button>
                        </form>
                    ) : (
                        <p className="text-sm mt-3 text-ink-muted">{order.payment_status === 'transfer_reported' ? `Reported with reference ${order.bank_reference}. The business will verify it — this does not mark the order paid.` : null}</p>
                    )}
                </Card>
            )}

            <Card className="mt-4">
                <h2 className="font-semibold mb-3">History</h2>
                <ul className="space-y-1 text-sm">
                    {events.map((e, k) => (
                        <li key={k} className="flex justify-between gap-3"><span>{e.to ? STATUS_LABEL[e.to] : e.type.replace(/_/g, ' ')}</span><span className="text-ink-muted">{e.at}</span></li>
                    ))}
                </ul>
            </Card>
        </PublicShell>
    );
}
