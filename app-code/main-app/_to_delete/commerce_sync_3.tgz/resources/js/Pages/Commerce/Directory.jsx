import React from 'react';
import { Head, Link, router } from '@inertiajs/react';
import PublicShell from '@/Components/Commerce/PublicShell';
import { Card, Pager, Pill } from '@/Components/Commerce/ui';

export default function Directory({ countries, country, cities, city, stores }) {
    const go = (params) => router.get('/shop', params, { preserveScroll: true });

    return (
        <PublicShell>
            <Head title="Find a business near you">
                <meta name="description" content="Browse local businesses and order directly from them." />
            </Head>

            <h1 className="text-2xl font-bold">Find a business near you</h1>
            <p className="text-ink-muted mt-1 text-sm">Choose a country and city, then open a business to browse its catalogue and place an order.</p>

            <div className="grid sm:grid-cols-2 gap-4 mt-6">
                <label className="block">
                    <span className="block text-sm font-medium text-ink-secondary mb-1">Country</span>
                    <select className="w-full rounded-xl border border-line bg-surface px-3 py-2 text-sm" value={country?.code || ''}
                        onChange={(e) => go(e.target.value ? { country: e.target.value } : {})}>
                        <option value="">Select a country</option>
                        {countries.map((c) => <option key={c.id} value={c.code}>{c.name}</option>)}
                    </select>
                </label>
                <label className="block">
                    <span className="block text-sm font-medium text-ink-secondary mb-1">City</span>
                    <select className="w-full rounded-xl border border-line bg-surface px-3 py-2 text-sm" value={city?.slug || ''} disabled={!country}
                        onChange={(e) => go(e.target.value ? { country: country.code, city: e.target.value } : { country: country.code })}>
                        <option value="">{country ? 'Select a city' : 'Choose a country first'}</option>
                        {cities.map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}
                    </select>
                </label>
            </div>

            <div className="mt-8">
                {!city && <Card><p className="text-ink-muted text-sm">Select a city to see the businesses taking online orders there.</p></Card>}

                {city && stores && stores.data.length === 0 && (
                    <Card>
                        <p className="font-semibold">No businesses are live in {city.name} yet.</p>
                        <p className="text-ink-muted text-sm mt-1">Check back soon, or try another city.</p>
                    </Card>
                )}

                {city && stores && stores.data.length > 0 && (
                    <>
                        <p className="text-sm text-ink-muted mb-3">{stores.total} business{stores.total === 1 ? '' : 'es'} in {city.name}</p>
                        <ul className="grid sm:grid-cols-2 gap-4">
                            {stores.data.map((s) => (
                                <li key={s.slug}>
                                    <Card className="h-full flex flex-col gap-3">
                                        <div className="flex items-start gap-3">
                                            {s.logo_url
                                                ? <img src={s.logo_url} alt="" className="w-14 h-14 rounded-xl object-cover bg-sunken" loading="lazy" />
                                                : <div className="w-14 h-14 rounded-xl bg-sunken flex items-center justify-center text-xl font-bold text-ink-muted" aria-hidden="true">{s.name?.[0]}</div>}
                                            <div className="min-w-0">
                                                <h2 className="font-semibold text-ink truncate">{s.name}</h2>
                                                <p className="text-sm text-ink-muted">{s.address}</p>
                                            </div>
                                        </div>
                                        <div className="flex flex-wrap gap-2">
                                            {s.open_now === true && <Pill tone="bg-emerald-100 text-emerald-800">Open now</Pill>}
                                            {s.open_now === false && <Pill tone="bg-neutral-200 text-neutral-700">Closed now</Pill>}
                                            {s.pickup && <Pill>Pickup</Pill>}
                                            {s.delivery && <Pill>Delivery</Pill>}
                                        </div>
                                        <Link href={`/shop/${s.slug}`} className="mt-auto inline-flex justify-center px-4 py-2 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700">
                                            Open store
                                        </Link>
                                    </Card>
                                </li>
                            ))}
                        </ul>
                        <Pager current={stores.current} last={stores.last} onGo={(p) => go({ country: country.code, city: city.slug, page: p })} />
                    </>
                )}
            </div>
        </PublicShell>
    );
}
