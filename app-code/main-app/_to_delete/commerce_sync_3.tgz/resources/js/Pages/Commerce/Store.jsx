import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Head, router } from '@inertiajs/react';
import axios from 'axios';
import PublicShell from '@/Components/Commerce/PublicShell';
import { Alert, Button, Card, Field, inputCls, Pager, Pill } from '@/Components/Commerce/ui';
import { DAY_LABEL, cartStore, money, newKey } from '@/lib/commerce';

const DAYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];

export default function Store({ store, items, pagination, limits }) {
    const sym = store.currency_symbol;
    const [cart, setCart] = useState({ slug: store.slug, lines: [] });
    const [pendingSwitch, setPendingSwitch] = useState(null); // item waiting for "replace cart?" answer
    const [quote, setQuote] = useState(null);
    const [problems, setProblems] = useState([]);
    const [notice, setNotice] = useState(null);
    const [busy, setBusy] = useState(false);
    const [fulfilment, setFulfilment] = useState(store.pickup ? 'pickup' : 'delivery');
    const [form, setForm] = useState({ customer_name: '', customer_phone: '', delivery_address: '', customer_note: '', payment_method: '' });
    const [fieldErrors, setFieldErrors] = useState({});
    const attempt = useRef({ sig: '', key: '' });
    const names = useRef({}); // item_id -> name for lines not on the current catalogue page
    items.forEach((i) => { names.current[i.id] = i.name; });

    // hydrate cart (single business per cart)
    useEffect(() => {
        const c = cartStore.read();
        if (c.slug === store.slug) setCart(c);
    }, [store.slug]);

    const persist = (next) => { setCart(next); cartStore.write(next); };

    const methods = useMemo(() => {
        const m = [];
        if (fulfilment === 'delivery' && store.payments.cod) m.push(['cod', 'Cash on delivery']);
        if (fulfilment === 'pickup' && store.payments.pickup) m.push(['pickup', 'Pay at pickup']);
        if (store.payments.bank) m.push(['bank', 'Bank transfer']);
        return m;
    }, [fulfilment, store.payments]);

    useEffect(() => {
        if (!methods.find(([k]) => k === form.payment_method)) {
            setForm((f) => ({ ...f, payment_method: methods[0]?.[0] || '' }));
        }
    }, [methods]); // eslint-disable-line react-hooks/exhaustive-deps

    // server quote (debounced) — the browser never computes prices
    useEffect(() => {
        if (cart.lines.length === 0) { setQuote(null); setProblems([]); return undefined; }
        const t = setTimeout(() => {
            axios.post(`/shop/${store.slug}/quote`, { items: cart.lines.map((l) => ({ item_id: l.item_id, quantity: l.quantity })), fulfilment })
                .then((r) => { setQuote(r.data); setProblems([]); })
                .catch((e) => {
                    const d = e.response?.data;
                    if (d?.reason === 'cart_changed') { setProblems(d.problems || []); setQuote(null); }
                    else setNotice(d?.message || 'Could not price your cart. Please try again.');
                });
        }, 250);
        return () => clearTimeout(t);
    }, [cart.lines, fulfilment, store.slug]);

    const add = (item) => {
        const cur = cartStore.read();
        if (cur.slug && cur.slug !== store.slug && cur.lines.length > 0) { setPendingSwitch(item); return; }
        const lines = [...cart.lines];
        const ex = lines.find((l) => l.item_id === item.id);
        if (ex) ex.quantity = Math.min(limits.max_qty, ex.quantity + 1); else lines.push({ item_id: item.id, quantity: 1 });
        persist({ slug: store.slug, lines });
    };
    const setQty = (id, q) => {
        const lines = cart.lines.map((l) => (l.item_id === id ? { ...l, quantity: Math.max(0, Math.min(limits.max_qty, q)) } : l)).filter((l) => l.quantity > 0);
        persist({ slug: store.slug, lines });
    };
    const removeProblems = () => persist({ slug: store.slug, lines: cart.lines.filter((l) => !problems.some((p) => p.item_id === l.item_id)) });

    const count = cart.lines.reduce((n, l) => n + l.quantity, 0);
    const minOrder = Number(store.min_order_amount || 0);
    const belowMin = quote && minOrder > 0 && (quote.subtotal + quote.tax_total) < minOrder;
    const canSubmit = store.accepting_orders && quote && !belowMin && !busy && problems.length === 0 && form.customer_name.trim() && form.customer_phone.trim() && form.payment_method && (fulfilment === 'pickup' || form.delivery_address.trim());

    const submit = async (e) => {
        e.preventDefault();
        if (!canSubmit) return;
        setBusy(true); setNotice(null); setFieldErrors({});
        const payload = {
            fulfilment, payment_method: form.payment_method, customer_name: form.customer_name, customer_phone: form.customer_phone,
            delivery_address: fulfilment === 'delivery' ? form.delivery_address : null, customer_note: form.customer_note || null,
            items: cart.lines.map((l) => ({ item_id: l.item_id, quantity: l.quantity })), expected_total: quote.total,
        };
        // same key for a retry of the SAME order; a changed order gets a new key
        const sig = JSON.stringify(payload);
        if (attempt.current.sig !== sig) attempt.current = { sig, key: newKey() };
        try {
            const r = await axios.post(`/shop/${store.slug}/checkout`, { ...payload, idempotency_key: attempt.current.key });
            cartStore.clear();
            window.location.href = r.data.status_url;
        } catch (err) {
            const d = err.response?.data;
            if (err.response?.status === 422 && d?.errors) setFieldErrors(d.errors);
            if (d?.reason === 'quote_changed') { setQuote(d.quote); setNotice('Prices changed while you were checking out. Please review the new total and confirm again.'); }
            else if (d?.reason === 'cart_changed') { setProblems(d.problems || []); }
            else setNotice(d?.message || 'We could not place your order. Please try again — you will not be charged twice.');
        } finally { setBusy(false); }
    };

    const hours = store.opening_hours;

    return (
        <PublicShell title={store.name}>
            <Head title={`${store.name}${store.city ? ` — ${store.city}` : ''}`}>
                <meta name="description" content={store.description || `Order from ${store.name}${store.city ? ` in ${store.city}` : ''}.`} />
            </Head>

            <section className="flex flex-wrap items-start gap-4">
                {store.logo_url && <img src={store.logo_url} alt="" className="w-20 h-20 rounded-2xl object-cover bg-sunken" />}
                <div className="flex-1 min-w-60">
                    <h1 className="text-2xl font-bold">{store.name}</h1>
                    {store.description && <p className="text-sm text-ink-secondary mt-1">{store.description}</p>}
                    <p className="text-sm text-ink-muted mt-1">{[store.address, store.city].filter(Boolean).join(' · ')}</p>
                    <div className="flex flex-wrap gap-2 mt-2">
                        {store.open_now === true && <Pill tone="bg-emerald-100 text-emerald-800">Open now</Pill>}
                        {store.open_now === false && <Pill tone="bg-neutral-200 text-neutral-700">Closed now</Pill>}
                        {store.pickup && <Pill>Pickup</Pill>}
                        {store.delivery && <Pill>Delivery {Number(store.delivery_charge) > 0 ? `· ${money(store.delivery_charge, sym)}` : '· free'}</Pill>}
                        {minOrder > 0 && <Pill>Minimum order {money(minOrder, sym)}</Pill>}
                    </div>
                    <p className="text-sm mt-2 flex flex-wrap gap-x-4">
                        {store.phone && <a className="underline" href={`tel:${store.phone}`}>{store.phone}</a>}
                        {store.map_url && <a className="underline" href={store.map_url} target="_blank" rel="noopener noreferrer">View on map</a>}
                    </p>
                    {store.delivery_note && <p className="text-xs text-ink-muted mt-1">{store.delivery_note}</p>}
                </div>
                {hours && (
                    <details className="text-sm bg-surface border border-line rounded-xl px-3 py-2">
                        <summary className="cursor-pointer font-medium">Opening hours</summary>
                        <ul className="mt-2 space-y-0.5">
                            {DAYS.map((d) => <li key={d} className="flex justify-between gap-6"><span>{DAY_LABEL[d]}</span><span className="text-ink-muted">{hours[d] ? `${hours[d].open}–${hours[d].close}` : 'Closed'}</span></li>)}
                        </ul>
                    </details>
                )}
            </section>

            {!store.accepting_orders && <div className="mt-4"><Alert kind="warn">This business is not taking online orders right now. You can still look around.</Alert></div>}
            {pendingSwitch && (
                <div className="mt-4"><Alert kind="warn">
                    Your cart has items from another business. A cart can only hold one business at a time.
                    <span className="flex gap-2 mt-2">
                        <Button onClick={() => { persist({ slug: store.slug, lines: [{ item_id: pendingSwitch.id, quantity: 1 }] }); setPendingSwitch(null); }}>Replace cart</Button>
                        <Button variant="secondary" onClick={() => setPendingSwitch(null)}>Keep my other cart</Button>
                    </span>
                </Alert></div>
            )}

            <div className="grid lg:grid-cols-3 gap-6 mt-6">
                <section className="lg:col-span-2" aria-label="Catalogue">
                    {items.length === 0 ? (
                        <Card><p className="text-sm text-ink-muted">This business has not published any products yet.</p></Card>
                    ) : (
                        <ul className="grid sm:grid-cols-2 gap-4">
                            {items.map((it) => {
                                const inCart = cart.lines.find((l) => l.item_id === it.id)?.quantity || 0;
                                return (
                                    <li key={it.id}>
                                        <Card className="h-full flex flex-col gap-2">
                                            {it.image_url && <img src={it.image_url} alt="" loading="lazy" className="w-full h-40 object-cover rounded-xl bg-sunken" />}
                                            <h2 className="font-semibold text-ink">{it.name}</h2>
                                            {it.description && <p className="text-sm text-ink-muted line-clamp-3">{it.description}</p>}
                                            <div className="mt-auto flex items-center justify-between pt-2">
                                                <span className="font-bold tabular-nums">{money(it.price, sym)}<span className="text-xs font-normal text-ink-muted"> / {it.unit}</span></span>
                                                {inCart > 0 ? (
                                                    <span className="inline-flex items-center gap-2">
                                                        <Button variant="secondary" aria-label={`Remove one ${it.name}`} onClick={() => setQty(it.id, inCart - 1)}>−</Button>
                                                        <span className="w-6 text-center tabular-nums">{inCart}</span>
                                                        <Button variant="secondary" aria-label={`Add one ${it.name}`} onClick={() => add(it)}>+</Button>
                                                    </span>
                                                ) : (
                                                    <Button onClick={() => add(it)} disabled={!store.accepting_orders}>Add</Button>
                                                )}
                                            </div>
                                        </Card>
                                    </li>
                                );
                            })}
                        </ul>
                    )}
                    <Pager current={pagination.current} last={pagination.last}
                        onGo={(p) => router.get(`/shop/${store.slug}`, { page: p }, { preserveState: true, preserveScroll: false, only: ['items', 'pagination'] })} />
                </section>

                <aside aria-label="Your cart" className="lg:sticky lg:top-4 self-start">
                    <Card>
                        <h2 className="font-bold text-lg">Your order {count > 0 && <span className="text-ink-muted font-normal text-sm">({count} item{count === 1 ? '' : 's'})</span>}</h2>
                        {cart.lines.length === 0 ? <p className="text-sm text-ink-muted mt-2">Your cart is empty.</p> : (
                            <form onSubmit={submit} className="mt-3 space-y-4">
                                {problems.length > 0 && (
                                    <Alert kind="error">
                                        Some items are no longer available:
                                        <ul className="list-disc ml-5 mt-1">{problems.map((p, i) => <li key={i}>{names.current[p.item_id] || 'An item'} — {p.message}</li>)}</ul>
                                        <Button variant="secondary" className="mt-2" onClick={removeProblems}>Remove them</Button>
                                    </Alert>
                                )}
                                <ul className="divide-y divide-line">
                                    {cart.lines.map((l) => {
                                        const q = quote?.items?.find((x) => x.item_id === l.item_id);
                                        return (
                                            <li key={l.item_id} className="py-2 flex items-center justify-between gap-2 text-sm">
                                                <span className="min-w-0"><span className="block truncate">{q?.title || names.current[l.item_id] || 'Item'}</span>
                                                    {q && <span className="text-xs text-ink-muted tabular-nums">{money(q.price, sym)} each</span>}</span>
                                                <span className="inline-flex items-center gap-1">
                                                    <button type="button" className="w-7 h-7 rounded-lg bg-sunken" aria-label="Decrease quantity" onClick={() => setQty(l.item_id, l.quantity - 1)}>−</button>
                                                    <span className="w-6 text-center tabular-nums">{l.quantity}</span>
                                                    <button type="button" className="w-7 h-7 rounded-lg bg-sunken" aria-label="Increase quantity" onClick={() => setQty(l.item_id, l.quantity + 1)}>+</button>
                                                </span>
                                                <span className="w-24 text-right tabular-nums">{q ? money(q.line_total, sym) : '…'}</span>
                                            </li>
                                        );
                                    })}
                                </ul>

                                <fieldset>
                                    <legend className="text-sm font-medium text-ink-secondary mb-1">How would you like to get it?</legend>
                                    <div className="flex gap-2">
                                        {store.pickup && <label className={`flex-1 text-center rounded-xl border px-3 py-2 text-sm cursor-pointer ${fulfilment === 'pickup' ? 'border-brand-600 bg-brand-50 text-brand-700' : 'border-line'}`}><input type="radio" className="sr-only" name="f" checked={fulfilment === 'pickup'} onChange={() => setFulfilment('pickup')} />Pickup</label>}
                                        {store.delivery && <label className={`flex-1 text-center rounded-xl border px-3 py-2 text-sm cursor-pointer ${fulfilment === 'delivery' ? 'border-brand-600 bg-brand-50 text-brand-700' : 'border-line'}`}><input type="radio" className="sr-only" name="f" checked={fulfilment === 'delivery'} onChange={() => setFulfilment('delivery')} />Delivery</label>}
                                    </div>
                                </fieldset>

                                <Field label="Your name" error={fieldErrors.customer_name?.[0]}><input className={inputCls} value={form.customer_name} onChange={(e) => setForm({ ...form, customer_name: e.target.value })} autoComplete="name" required maxLength={150} /></Field>
                                <Field label="Phone number" error={fieldErrors.customer_phone?.[0]} hint="So the business can reach you about this order."><input className={inputCls} value={form.customer_phone} onChange={(e) => setForm({ ...form, customer_phone: e.target.value })} inputMode="tel" autoComplete="tel" required maxLength={40} /></Field>
                                {fulfilment === 'delivery' && <Field label="Delivery address" error={fieldErrors.delivery_address?.[0]}><textarea className={inputCls} rows={3} value={form.delivery_address} onChange={(e) => setForm({ ...form, delivery_address: e.target.value })} required maxLength={500} /></Field>}
                                <Field label="Note for the business (optional)"><textarea className={inputCls} rows={2} value={form.customer_note} onChange={(e) => setForm({ ...form, customer_note: e.target.value })} maxLength={500} /></Field>

                                <fieldset>
                                    <legend className="text-sm font-medium text-ink-secondary mb-1">Payment</legend>
                                    {methods.length === 0 && <p className="text-sm text-red-600">No payment option is available for this choice.</p>}
                                    {methods.map(([k, label]) => (
                                        <label key={k} className="flex items-center gap-2 text-sm py-1"><input type="radio" name="pm" checked={form.payment_method === k} onChange={() => setForm({ ...form, payment_method: k })} />{label}</label>
                                    ))}
                                    {form.payment_method === 'bank' && store.payments.bank_instructions && <p className="text-xs text-ink-muted mt-1 whitespace-pre-line">{store.payments.bank_instructions}</p>}
                                </fieldset>

                                {quote && (
                                    <dl className="text-sm space-y-1 border-t border-line pt-3">
                                        <div className="flex justify-between"><dt className="text-ink-muted">Subtotal</dt><dd className="tabular-nums">{money(quote.subtotal, sym)}</dd></div>
                                        {quote.tax_total > 0 && <div className="flex justify-between"><dt className="text-ink-muted">Tax</dt><dd className="tabular-nums">{money(quote.tax_total, sym)}</dd></div>}
                                        {quote.delivery_fee > 0 && <div className="flex justify-between"><dt className="text-ink-muted">Delivery</dt><dd className="tabular-nums">{money(quote.delivery_fee, sym)}</dd></div>}
                                        <div className="flex justify-between font-bold text-base"><dt>Total</dt><dd className="tabular-nums">{money(quote.total, sym)}</dd></div>
                                    </dl>
                                )}
                                {belowMin && <Alert kind="warn">Minimum order is {money(minOrder, sym)}.</Alert>}
                                {notice && <Alert kind="error">{notice}</Alert>}
                                <Button type="submit" className="w-full" disabled={!canSubmit} onClick={() => {}}>{busy ? 'Placing order…' : 'Place order request'}</Button>
                                <p className="text-xs text-ink-muted">The business confirms availability before your order is accepted. You pay as chosen above — nothing is charged online.</p>
                            </form>
                        )}
                    </Card>
                </aside>
            </div>
        </PublicShell>
    );
}
