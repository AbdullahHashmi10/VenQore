<?php

namespace App\Http\Controllers\Commerce;

use App\Http\Controllers\Controller;
use App\Models\Commerce\CommerceOrder;
use App\Models\Commerce\Storefront;
use App\Services\Commerce\CheckoutService;
use App\Services\Commerce\CommerceException;
use App\Services\Commerce\OnlinePricing;
use App\Services\Commerce\OrderService;
use App\Services\Commerce\ProductReadiness;
use App\Services\Commerce\StorefrontPresenter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;

/**
 * Public, unauthenticated surface. Fails closed: nothing is read through ambient tenant scopes, only through
 * an explicit published storefront, and only allow-listed fields are returned.
 */
class PublicStoreController extends Controller
{
    public function __construct(private CheckoutService $checkout, private OrderService $orders)
    {
    }

    private function published(string $slug): Storefront
    {
        return Storefront::where('slug', $slug)->where('status', 'published')->firstOrFail();
    }

    public function directory(Request $request)
    {
        $countries = DB::table('commerce_countries')->where('is_active', 1)->orderBy('name')->get(['id', 'code', 'name']);
        $country = $countries->firstWhere('code', strtoupper((string) $request->query('country'))) ?? ($countries->count() === 1 ? $countries->first() : null);
        $cities = $country ? DB::table('commerce_cities')->where('country_id', $country->id)->where('is_active', 1)->orderBy('sort_order')->orderBy('name')->get(['id', 'name', 'slug']) : collect();
        $city = $country ? $cities->firstWhere('slug', (string) $request->query('city')) : null;

        $stores = null;
        if ($city) {
            $page = Storefront::where('status', 'published')->where('city_id', $city->id)
                ->orderBy('display_name')->orderBy('id')->paginate(12)->withQueryString();
            $stores = [
                'data' => collect($page->items())->map(fn ($s) => StorefrontPresenter::card($s))->values(),
                'current' => $page->currentPage(), 'last' => $page->lastPage(), 'total' => $page->total(),
            ];
        }

        return Inertia::render('Commerce/Directory', [
            'countries' => $countries, 'country' => $country, 'cities' => $cities, 'city' => $city, 'stores' => $stores,
        ]);
    }

    public function show(Request $request, string $slug)
    {
        $store = $this->published($slug);
        $q = trim((string) $request->query('q', ''));
        $cat = (string) $request->query('category', '');
        $base = fn () => DB::table('storefront_products as sp')
            ->join('products as p', function ($j) {
                $j->on('p.id', '=', 'sp.product_id')->on('p.tenant_id', '=', 'sp.tenant_id');
            })
            ->where('sp.storefront_id', $store->id)->where('sp.tenant_id', $store->tenant_id)->where('sp.is_published', 1)
            ->whereNull('p.deleted_at');
        $categories = $base()->join('categories as c', 'c.id', '=', 'p.category_id')
            ->groupBy('c.id', 'c.name')->orderBy('c.name')
            ->get(['c.id', 'c.name', DB::raw('count(*) as n')])
            ->map(fn ($c) => ['id' => $c->id, 'name' => $c->name, 'count' => (int) $c->n])->values();
        $rows = DB::table('storefront_products as sp')
            ->join('products as p', function ($j) {
                $j->on('p.id', '=', 'sp.product_id')->on('p.tenant_id', '=', 'sp.tenant_id');
            })
            ->where('sp.storefront_id', $store->id)->where('sp.tenant_id', $store->tenant_id)->where('sp.is_published', 1)
            ->whereNull('p.deleted_at')
            ->when($cat !== '', fn ($w) => $w->where('p.category_id', $cat))
            ->when($q !== '', fn ($w) => $w->where(function ($x) use ($q) {
                $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], mb_substr($q, 0, 60)) . '%';
                $x->where('p.name', 'like', $like)->orWhere('sp.public_name', 'like', $like);
            }))
            ->orderByDesc('sp.is_featured')->orderBy('sp.sort_order')->orderBy('p.name')->orderBy('sp.id')
            ->select(['sp.is_featured', 'p.category_id', 'sp.id as listing_id', 'sp.public_name', 'sp.public_description', 'sp.override_price', 'sp.allow_below_cost', 'sp.product_id',
                'sp.image_path as listing_image', 'p.id', 'p.tenant_id', 'p.name', 'p.description', 'p.image_path', 'p.price', 'p.cost_price', 'p.tax_rate', 'p.price_includes_tax',
                'p.base_unit', 'p.unit', 'p.is_active', 'p.type', 'p.has_variants', 'p.is_weighted', 'p.track_serial'])
            ->paginate(24)->withQueryString();

        $pricing = app(OnlinePricing::class);
        $promos = app(\App\Services\Commerce\Promotions::class);
        $plan = ['coupon' => null, 'auto' => $promos->live($store)->filter(fn ($p) => $p->code === null && (float) $p->min_order <= 0)->values()];
        $catNames = $categories->pluck('name', 'id');
        $stockSvc = app(\App\Services\Commerce\StockAvailability::class);
        $items = collect($rows->items())->map(function ($r) use ($pricing, $store, $promos, $plan, $catNames, $stockSvc) {
            if (ProductReadiness::reason($r) !== null) {
                return null;
            }
            $price = $pricing->resolve($r, $r, $store);
            if ($price['below_cost'] && ! $r->allow_below_cost) {
                return null;
            }
            $was = null;
            if ($promo = $promos->pickFor($plan, $r->category_id)) {
                $d = $pricing->discount($price, $r, (float) $promo->percent);
                if (! $d['below_cost'] || $r->allow_below_cost) {
                    $was = $price['online_price'];
                    $price = $d;
                }
            }
            $left = $store->warehouse_id ? $stockSvc->available($store->tenant_id, $r->id, $store->warehouse_id) : null;
            return [
                'category' => $catNames[$r->category_id] ?? null,
                'stock' => $left === null ? null : ($left <= 0 ? 'out' : ($left <= 5 ? 'low' : null)),
                'left' => $left !== null && $left > 0 && $left <= 5 ? (int) floor($left) : null,
                'featured' => (bool) $r->is_featured,
                'was_price' => $was,
                'id' => $r->listing_id,
                'name' => $r->public_name ?: $r->name,
                'description' => $r->public_description ?: $r->description,
                'image_url' => $store->show_images ? StorefrontPresenter::mediaUrl($r->listing_image ?: $r->image_path) : null,
                'price' => $price['online_price'],
                'unit' => $r->base_unit ?: $r->unit,
            ];
        })->filter()->values();

        return Inertia::render('Commerce/Store', [
            'store' => StorefrontPresenter::publicStore($store),
            'items' => $items,
            'pagination' => ['current' => $rows->currentPage(), 'last' => $rows->lastPage(), 'total' => $rows->total()],
            'limits' => ['max_qty' => CheckoutService::MAX_QTY],
            'categories' => $categories,
            'filters' => ['q' => $q, 'category' => $cat],
            'show_images' => (bool) $store->show_images,
            'has_coupons' => $promos->live($store)->contains(fn ($p) => $p->code !== null),
        ]);
    }

    public function quote(Request $request, string $slug)
    {
        $store = $this->published($slug);
        $data = $request->validate(['items' => ['required', 'array', 'max:' . CheckoutService::MAX_LINES], 'items.*.item_id' => ['required', 'string', 'max:36'], 'items.*.quantity' => ['required', 'integer', 'min:1', 'max:' . CheckoutService::MAX_QTY], 'fulfilment' => ['nullable', 'in:pickup,delivery'], 'delivery_zone' => ['nullable', 'string', 'max:120'], 'coupon' => ['nullable', 'string', 'max:40']]);
        try {
            $q = $this->checkout->quote($store, $data['items'], $data['fulfilment'] ?? 'pickup', ['zone' => $data['delivery_zone'] ?? null, 'coupon' => $data['coupon'] ?? null]);
        } catch (CommerceException $e) {
            return response()->json(['message' => $e->getMessage(), 'reason' => $e->reason] + $e->payload, $e->httpStatus);
        }
        return response()->json($this->publicQuote($q));
    }

    public function placeOrder(Request $request, string $slug)
    {
        $store = Storefront::where('slug', $slug)->firstOrFail(); // let replays work even if the store was just unpublished
        $data = $request->validate([
            'idempotency_key' => ['required', 'string', 'min:16', 'max:100'],
            'fulfilment' => ['required', 'in:pickup,delivery'],
            'payment_method' => ['required', 'in:cod,pickup,bank'],
            'customer_name' => ['required', 'string', 'max:150'],
            'customer_phone' => ['required', 'string', 'max:40'],
            'delivery_address' => ['nullable', 'string', 'max:500'],
            'delivery_zone' => ['nullable', 'string', 'max:120'],
            'coupon' => ['nullable', 'string', 'max:40'],
            'customer_note' => ['nullable', 'string', 'max:500'],
            'expected_total' => ['nullable', 'numeric'],
            'items' => ['required', 'array', 'min:1', 'max:' . CheckoutService::MAX_LINES],
            'items.*.item_id' => ['required', 'string', 'max:36'],
            'items.*.quantity' => ['required', 'integer', 'min:1', 'max:' . CheckoutService::MAX_QTY],
        ]);
        try {
            $r = $this->checkout->place($store, $data);
        } catch (CommerceException $e) {
            return response()->json(['message' => $e->getMessage(), 'reason' => $e->reason] + ($e->reason === 'quote_changed' ? ['quote' => $this->publicQuote($e->payload['quote'])] : $e->payload), $e->httpStatus);
        }
        return response()->json([
            'order_number' => $r['order']->public_number,
            'status_url' => url('/order-status/' . $r['token']),
            'replayed' => $r['replayed'],
        ], $r['replayed'] ? 200 : 201);
    }

    public function status(Request $request, string $token)
    {
        $order = $this->orderByToken($token);
        $store = Storefront::find($order->storefront_id);

        $publicEvents = $order->events()->whereIn('type', ['placed', 'status_changed', 'completed', 'expired', 'confirmed', 'rejected', 'cancelled', 'transfer_reported', 'payment_collected'])
            ->get(['type', 'to_status', 'created_at'])->map(fn ($e) => ['type' => $e->type, 'to' => $e->to_status, 'at' => CommerceOrder::localTime($e->created_at, $order->storefront?->timezone ?? 'UTC')]);

        $resp = Inertia::render('Commerce/OrderStatus', [
            'order' => [
                'number' => $order->public_number, 'status' => $order->status, 'payment_status' => $order->payment_status,
                'payment_method' => $order->payment_method, 'fulfilment' => $order->fulfilment, 'customer_name' => $order->customer_name,
                'delivery_address' => $order->delivery_address, 'reason' => in_array($order->status, ['rejected', 'cancelled', 'expired'], true) ? $order->reason : null,
                'subtotal' => $order->subtotal, 'tax_total' => $order->tax_total, 'delivery_fee' => $order->delivery_fee, 'total' => $order->total,
                'currency_symbol' => $order->currency_symbol, 'placed_at' => CommerceOrder::localTime($order->created_at, $order->storefront?->timezone ?? 'UTC'),
                'bank_reference' => $order->bank_reference, 'delivery_zone' => $order->delivery_zone,
                'discount_total' => $order->discount_total, 'promo_name' => $order->promo_name, 'promo_code' => $order->promo_code,
                'items' => $order->items()->get(['title', 'quantity', 'online_price', 'line_total'])->map(fn ($i) => $i->only(['title', 'quantity', 'online_price', 'line_total'])),
            ],
            'events' => $publicEvents,
            'store' => ['name' => $store->display_name, 'phone' => $store->phone, 'address' => $store->address_line, 'slug' => $store->slug,
                'bank_instructions' => ($order->payment_method === 'bank' && $order->payment_status !== 'collected') ? $store->bank_instructions : null],
            'transfer_url' => url('/order-status/' . $token . '/transfer'),
            'reorder_url' => $store->status === 'published' ? url('/order-status/' . $token . '/reorder') : null,
            'prep_minutes' => $store->prep_minutes,
        ])->toResponse($request);

        // private, never indexed, never cached, never leaks the token via Referer
        $resp->headers->set('X-Robots-Tag', 'noindex, nofollow, noarchive');
        $resp->headers->set('Cache-Control', 'no-store, private');
        $resp->headers->set('Referrer-Policy', 'no-referrer');
        return $resp;
    }

    public function reportTransfer(Request $request, string $token)
    {
        $order = $this->orderByToken($token);
        $v = $request->validate(['reference' => ['required', 'string', 'min:3', 'max:120']]);
        try {
            $this->orders->reportTransfer($order->id, $order->tenant_id, $v['reference']);
        } catch (CommerceException $e) {
            return back()->withErrors(['reference' => $e->getMessage()]);
        }
        return back()->with('success', 'Thanks. The business will verify your transfer.');
    }

    private function orderByToken(string $token): CommerceOrder
    {
        abort_unless(preg_match('/^[A-Za-z0-9]{48}$/', $token) === 1, 404);
        return CommerceOrder::where('status_token_hash', hash('sha256', $token))->firstOrFail();
    }

    private function publicQuote(array $q): array
    {
        return [
            'items' => collect($q['items'])->map(fn ($i) => ['item_id' => $i['item_id'], 'title' => $i['title'], 'quantity' => $i['quantity'], 'price' => $i['online_price'], 'line_total' => $i['line_total']])->values(),
            'subtotal' => $q['subtotal'], 'tax_total' => $q['tax_total'], 'delivery_fee' => $q['delivery_fee'], 'total' => $q['total'],
            'currency_symbol' => $q['currency_symbol'],
            'discount_total' => $q['discount_total'], 'promo_name' => $q['promo_name'], 'promo_code' => $q['promo_code'],
            'delivery_zone' => $q['delivery_zone'], 'zone_required' => $q['zone_required'], 'min_order' => $q['min_order'],
        ];
    }

    /** Secure reorder: the status token proves ownership. Returns only live listings; the cart then reprices via /quote. */
    public function reorder(Request $request, string $token)
    {
        $order = $this->orderByToken($token);
        $store = Storefront::find($order->storefront_id);
        abort_unless($store && $store->status === 'published', 404);
        $lines = DB::table('commerce_order_items as i')
            ->join('storefront_products as sp', fn ($j) => $j->on('sp.product_id', '=', 'i.product_id')->where('sp.storefront_id', $store->id)->where('sp.is_published', 1))
            ->where('i.order_id', $order->id)
            ->get(['sp.id as item_id', 'i.quantity', 'i.title'])
            ->map(fn ($l) => ['item_id' => $l->item_id, 'quantity' => (int) max(1, min(CheckoutService::MAX_QTY, $l->quantity)), 'title' => $l->title]);
        $resp = response()->json(['slug' => $store->slug, 'lines' => $lines, 'skipped' => max(0, $order->items()->count() - $lines->count())]);
        $resp->headers->set('Cache-Control', 'no-store, private');
        return $resp;
    }
}
