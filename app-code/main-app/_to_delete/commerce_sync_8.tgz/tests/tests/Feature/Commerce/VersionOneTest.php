<?php

namespace Tests\Feature\Commerce;

use App\Services\Commerce\CheckoutService;
use App\Services\Commerce\CommerceException;
use App\Services\Commerce\OrderService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class VersionOneTest extends CommerceTestCase
{
    private function promo(array $o = []): string
    {
        $id = (string) Str::uuid();
        DB::table('commerce_promotions')->insert(array_merge([
            'id' => $id, 'tenant_id' => $this->tenant->id, 'storefront_id' => $this->store->id, 'name' => 'Sale', 'code' => null,
            'percent' => 10, 'scope' => 'store', 'category_id' => null, 'starts_at' => null, 'ends_at' => null, 'min_order' => 0,
            'max_uses' => null, 'uses' => 0, 'is_active' => 1, 'created_at' => now(), 'updated_at' => now(),
        ], $o));
        return $id;
    }

    private function quote(array $items, string $f = 'pickup', array $opts = []): array
    {
        return app(CheckoutService::class)->quote($this->store->fresh(), $items, $f, $opts);
    }

    private function cat(string $name): string
    {
        $id = (string) Str::uuid();
        DB::table('categories')->insert(['id' => $id, 'tenant_id' => $this->tenant->id, 'name' => $name, 'created_at' => now(), 'updated_at' => now()]);
        return $id;
    }

    public function test_auto_offer_discounts_lines_and_snapshots_on_the_order(): void
    {
        $pid = $this->makeProduct($this->tenant, $this->warehouseId, [], 10, $this->store);
        $this->promo(['name' => 'Autumn 10', 'percent' => 10]);
        $q = $this->quote([['product_id' => $pid, 'quantity' => 2]]);
        $this->assertEquals(1800.0, $q['total']);
        $this->assertEquals(200.0, $q['discount_total']);
        $this->assertSame('Autumn 10', $q['promo_name']);
        $o = app(CheckoutService::class)->place($this->store->fresh(), $this->checkoutInput([['product_id' => $pid, 'quantity' => 2]]))['order'];
        $this->assertEquals(1800.0, $o->total);
        $this->assertEquals(1000.0, $o->items[0]->list_price);
        $this->assertEquals(10.0, $o->items[0]->discount_percent);
        // later promo edits never change the order
        DB::table('commerce_promotions')->update(['percent' => 50]);
        $this->assertEquals(1800.0, $o->fresh()->total);
    }

    public function test_posted_sale_total_equals_discounted_order_total(): void
    {
        $pid = $this->makeProduct($this->tenant, $this->warehouseId, ['tax_rate' => 10, 'price_includes_tax' => 0], 10, $this->store);
        $this->promo(['percent' => 20]);
        $o = app(CheckoutService::class)->place($this->store->fresh(), $this->checkoutInput([['product_id' => $pid, 'quantity' => 3]]))['order'];
        $svc = app(OrderService::class);
        $svc->confirm($o->id, $this->tenant->id, $this->owner->id);
        $svc->advance($o->id, $this->tenant->id, $this->owner->id, 'preparing');
        $svc->advance($o->id, $this->tenant->id, $this->owner->id, 'ready');
        $o = $svc->complete($o->id, $this->tenant->id, $this->owner->id, collectNow: true);
        $this->assertEquals((float) $o->total, (float) DB::table('sales')->where('id', $o->sale_id)->value('invoice_total'));
        $this->assertEquals(2640.0, (float) $o->total); // 3 x 800 net + 10% tax
    }

    public function test_dated_window_boundaries_are_utc_exact(): void
    {
        $pid = $this->makeProduct($this->tenant, $this->warehouseId, [], 10, $this->store);
        $this->promo(['name' => 'Future', 'starts_at' => now('UTC')->addMinute()->format('Y-m-d H:i:s')]);
        $this->promo(['name' => 'Past', 'ends_at' => now('UTC')->subSecond()->format('Y-m-d H:i:s')]);
        $this->promo(['name' => 'Off', 'is_active' => 0]);
        $this->assertEquals(1000.0, $this->quote([['product_id' => $pid, 'quantity' => 1]])['total']);
        $this->promo(['name' => 'Now', 'starts_at' => now('UTC')->subMinute()->format('Y-m-d H:i:s'), 'ends_at' => now('UTC')->addMinute()->format('Y-m-d H:i:s'), 'percent' => 5]);
        $this->assertEquals(950.0, $this->quote([['product_id' => $pid, 'quantity' => 1]])['total']);
    }

    public function test_precedence_best_auto_per_line_category_wins_tie_and_coupon_replaces_auto(): void
    {
        $c = $this->cat('Drinks');
        $a = $this->makeProduct($this->tenant, $this->warehouseId, ['category_id' => $c], 10, $this->store);
        $b = $this->makeProduct($this->tenant, $this->warehouseId, [], 10, $this->store);
        $this->promo(['name' => 'Store 10', 'percent' => 10]);
        $this->promo(['name' => 'Drinks 25', 'percent' => 25, 'scope' => 'category', 'category_id' => $c]);
        $q = $this->quote([['product_id' => $a, 'quantity' => 1], ['product_id' => $b, 'quantity' => 1]]);
        $this->assertEquals(750.0 + 900.0, $q['total']);
        $this->promo(['name' => 'Code 5', 'code' => 'SAVE5', 'percent' => 5]);
        $q = $this->quote([['product_id' => $a, 'quantity' => 1], ['product_id' => $b, 'quantity' => 1]], 'pickup', ['coupon' => 'save5']);
        $this->assertEquals(950.0 * 2, $q['total']); // coupon replaces the automatic offers entirely
        $this->assertSame('SAVE5', $q['promo_code']);
    }

    public function test_coupon_validation_min_order_cap_and_category_mismatch(): void
    {
        $pid = $this->makeProduct($this->tenant, $this->warehouseId, [], 10, $this->store);
        $id = $this->promo(['code' => 'ONCE', 'percent' => 10, 'max_uses' => 1, 'min_order' => 1500]);
        foreach ([['NOPE', 2], ['ONCE', 1]] as [$code, $qty]) {
            try {
                $this->quote([['product_id' => $pid, 'quantity' => $qty]], 'pickup', ['coupon' => $code]);
                $this->fail('expected invalid_coupon');
            } catch (CommerceException $e) {
                $this->assertSame('invalid_coupon', $e->reason);
            }
        }
        $in = $this->checkoutInput([['product_id' => $pid, 'quantity' => 2]], ['coupon' => 'once']);
        app(CheckoutService::class)->place($this->store->fresh(), $in);
        $this->assertSame(1, (int) DB::table('commerce_promotions')->where('id', $id)->value('uses'));
        $this->expectException(CommerceException::class);
        app(CheckoutService::class)->place($this->store->fresh(), $this->checkoutInput([['product_id' => $pid, 'quantity' => 2]], ['coupon' => 'ONCE', 'customer_phone' => '0300-9998887']));
    }

    public function test_offer_never_pushes_a_line_below_cost_without_approval(): void
    {
        $pid = $this->makeProduct($this->tenant, $this->warehouseId, ['price' => 1000, 'cost_price' => 900], 10, $this->store);
        $this->promo(['percent' => 50]);
        $this->assertEquals(1000.0, $this->quote([['product_id' => $pid, 'quantity' => 1]])['total']);
        DB::table('storefront_products')->where('product_id', $pid)->update(['allow_below_cost' => 1]);
        $this->assertEquals(500.0, $this->quote([['product_id' => $pid, 'quantity' => 1]])['total']);
    }

    public function test_delivery_zones_set_fee_and_minimum_and_reject_unknown_areas(): void
    {
        $pid = $this->makeProduct($this->tenant, $this->warehouseId, [], 10, $this->store);
        $this->store->update(['supports_delivery' => true, 'accept_cod' => true, 'delivery_charge' => 100, 'delivery_zones' => [
            ['name' => 'Gulberg', 'fee' => 150, 'min_order' => 0], ['name' => 'DHA', 'fee' => 300, 'min_order' => 2500]]]);
        $q = $this->quote([['product_id' => $pid, 'quantity' => 1]], 'delivery', ['zone' => 'gulberg']);
        $this->assertEquals(1150.0, $q['total']);
        $this->assertSame('Gulberg', $q['delivery_zone']);
        $this->assertTrue($this->quote([['product_id' => $pid, 'quantity' => 1]], 'delivery')['zone_required']);
        try {
            $this->quote([['product_id' => $pid, 'quantity' => 1]], 'delivery', ['zone' => 'Mars']);
            $this->fail('bad zone');
        } catch (CommerceException $e) {
            $this->assertSame('bad_zone', $e->reason);
        }
        $base = ['fulfilment' => 'delivery', 'payment_method' => 'cod', 'delivery_address' => '1 Road'];
        foreach ([[[], 'zone_required'], [['delivery_zone' => 'DHA'], 'below_minimum']] as [$extra, $reason]) {
            try {
                app(CheckoutService::class)->place($this->store->fresh(), $this->checkoutInput([['product_id' => $pid, 'quantity' => 1]], $base + $extra + ['idempotency_key' => (string) Str::uuid()]));
                $this->fail($reason);
            } catch (CommerceException $e) {
                $this->assertSame($reason, $e->reason);
            }
        }
        $o = app(CheckoutService::class)->place($this->store->fresh(), $this->checkoutInput([['product_id' => $pid, 'quantity' => 3]], $base + ['delivery_zone' => 'DHA']))['order'];
        $this->assertSame('DHA', $o->delivery_zone);
        $this->assertEquals(3300.0, $o->total);
    }
}
