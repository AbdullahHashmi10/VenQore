<?php

namespace App\Services\Commerce;

use App\Exceptions\ReservedStockException;
use Illuminate\Support\Facades\DB;

/**
 * Called by the sale engine right before FIFO deduction. A sale (POS or otherwise) may not
 * consume stock that an accepted online order is holding. The order's own sale is exempt.
 */
class HoldGuard
{
    /**
     * The enforcing check. Call it AFTER the inventory_batches rows for this product+warehouse are locked
     * FOR UPDATE, with $onHand summed from those locked rows (OrderService::confirm takes the same locks before
     * inserting a hold, which is what makes the two serialise).
     */
    public static function assertUnderLock(string $productId, string $warehouseId, float $baseQty, float $onHand, ?string $ownOrderId = null): void
    {
        $held = (float) DB::table('commerce_stock_holds')
            ->where('product_id', $productId)->where('warehouse_id', $warehouseId)->where('status', 'active')
            ->when($ownOrderId, fn ($q) => $q->where('order_id', '!=', $ownOrderId))
            ->lockForUpdate()->sum('quantity'); // latest committed holds, not a stale snapshot
        if ($held > 0 && $onHand - $held < $baseQty - 0.00005) {
            throw new ReservedStockException($productId, $warehouseId, $baseQty, max(0, round($onHand - $held, 4)), self::orders($productId, $warehouseId, $ownOrderId));
        }
    }

    /** Early, advisory check (not under lock). The authoritative check is assertUnderLock inside FifoService::deductStock. */
    public static function assertSellable(string $productId, string $warehouseId, float $baseQty, ?string $ownOrderId = null): void
    {
        $held = DB::table('commerce_stock_holds')
            ->where('product_id', $productId)->where('warehouse_id', $warehouseId)->where('status', 'active')
            ->when($ownOrderId, fn ($q) => $q->where('order_id', '!=', $ownOrderId))
            ->sum('quantity');
        if ((float) $held <= 0) {
            return;
        }
        $onHand = (float) DB::table('inventory_batches')
            ->where('product_id', $productId)->where('warehouse_id', $warehouseId)
            ->whereNull('deleted_at')->sum('remaining_qty');
        if ($onHand - (float) $held < $baseQty - 0.00005) {
            throw new ReservedStockException($productId, $warehouseId, $baseQty, max(0, round($onHand - (float) $held, 4)), self::orders($productId, $warehouseId, $ownOrderId));
        }
    }

    private static function orders(string $productId, string $warehouseId, ?string $own): array
    {
        return DB::table('commerce_stock_holds as h')->join('commerce_orders as o', 'o.id', '=', 'h.order_id')
            ->where('h.product_id', $productId)->where('h.warehouse_id', $warehouseId)->where('h.status', 'active')
            ->when($own, fn ($q) => $q->where('h.order_id', '!=', $own))->pluck('o.public_number')->unique()->values()->all();
    }
}
