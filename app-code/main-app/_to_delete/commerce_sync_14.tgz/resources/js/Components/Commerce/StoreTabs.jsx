import React, { useEffect, useRef, useState } from 'react';
import { Link, usePage } from '@inertiajs/react';
import { BadgePercent, Bell, ChevronRight, ExternalLink, LayoutDashboard, Package, Settings2, ShoppingBag } from 'lucide-react';

// short double beep (no audio file) when a NEW order arrives while this page is open
const beep = () => {
    try {
        const C = window.AudioContext || window.webkitAudioContext;
        if (!C) return;
        const ctx = new C();
        [0, 0.22].forEach((t) => {
            const o = ctx.createOscillator(); const g = ctx.createGain();
            o.type = 'sine'; o.frequency.value = 880; g.gain.value = 0.15;
            o.connect(g); g.connect(ctx.destination); o.start(ctx.currentTime + t); o.stop(ctx.currentTime + t + 0.16);
        });
        setTimeout(() => ctx.close(), 800);
    } catch { /* sound is optional */ }
};


/** Online Store sub-navigation + live in-app new-order alert (polls the alerts endpoint). */
export default function StoreTabs({ active, urls, status, title = 'Online Store', sub }) {
    const { flash } = usePage().props;
    const [alerts, setAlerts] = useState({ unread: 0, latest: [] });
    const seen = useRef(null);

    useEffect(() => {
        if (!urls?.alerts) return undefined;
        let stop = false;
        const load = () => fetch(urls.alerts, { headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' }, credentials: 'same-origin' })
            .then((r) => (r.ok ? r.json() : null))
            .then((j) => { if (j && !stop) { if (seen.current !== null && j.unread > seen.current) beep(); seen.current = j.unread; setAlerts(j); } })
            .catch(() => {});
        load();
        const t = setInterval(load, 10000);
        return () => { stop = true; clearInterval(t); };
    }, [urls?.alerts]);

    const tabs = [
        ['home', 'Overview', urls?.home, LayoutDashboard],
        ['orders', 'Orders', urls?.orders, ShoppingBag],
        ['products', 'Products', urls?.products, Package],
        ['promotions', 'Offers', urls?.promotions, BadgePercent],
        ['settings', 'Settings', urls?.settings, Settings2],
    ].filter(([, , href]) => !!href);
    const live = status === 'published';
    const latest = alerts.latest?.[0];

    return (
        <div className="mb-6">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <div className="min-w-0">
                    <div className="flex items-center gap-2">
                        <h1 className="text-2xl font-bold text-ink truncate">{title}</h1>
                        {status && (
                            <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${live ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300' : status === 'suspended' ? 'bg-rose-100 text-rose-800' : 'bg-sunken text-ink-secondary'}`}>
                                <span className={`h-1.5 w-1.5 rounded-full ${live ? 'bg-emerald-500 animate-pulse' : 'bg-neutral-400'}`} aria-hidden="true" />
                                {live ? 'Live' : status === 'suspended' ? 'Suspended' : 'Not live'}
                            </span>
                        )}
                    </div>
                    {sub && <p className="text-sm text-ink-muted mt-0.5">{sub}</p>}
                </div>
                {urls?.public && live && (
                    <a href={urls.public} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-xl border border-line bg-surface px-3.5 py-2 text-sm font-semibold text-ink hover:border-brand-400 hover:text-brand-700">
                        View store <ExternalLink size={14} aria-hidden="true" />
                    </a>
                )}
            </div>
            <nav aria-label="Online Store" className="-mx-1 overflow-x-auto">
                <div className="inline-flex min-w-full gap-1 rounded-2xl border border-line bg-surface p-1">
                    {tabs.map(([key, label, href, Icon]) => (
                        <Link key={key} href={href} aria-current={active === key ? 'page' : undefined}
                            className={`relative inline-flex items-center gap-2 whitespace-nowrap px-3.5 py-2 rounded-xl text-sm font-medium transition-colors ${active === key ? 'bg-brand-600 text-white shadow-sm' : 'text-ink-secondary hover:bg-interactive-hover hover:text-ink'}`}>
                            <Icon size={16} aria-hidden="true" />
                            {label}
                            {key === 'orders' && alerts.unread > 0 && (
                                <span className={`inline-flex items-center justify-center min-w-5 h-5 px-1.5 rounded-full text-xs font-bold ${active === key ? 'bg-white text-brand-700' : 'bg-rose-600 text-white'}`}>{alerts.unread}</span>
                            )}
                        </Link>
                    ))}
                </div>
            </nav>
            {alerts.unread > 0 && latest && (
                <a href={latest.url} className="group mt-3 flex items-center gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900 hover:border-amber-300 dark:bg-amber-900/20 dark:border-amber-800 dark:text-amber-200">
                    <span className="relative inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-amber-100 dark:bg-amber-900/40">
                        <Bell size={16} aria-hidden="true" />
                        <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-rose-500 ring-2 ring-amber-50" aria-hidden="true" />
                    </span>
                    <span className="min-w-0 flex-1 truncate font-medium">{latest.title}</span>
                    {alerts.unread > 1 && <span className="shrink-0 text-xs text-amber-800/80">+{alerts.unread - 1} more</span>}
                    <ChevronRight size={16} className="shrink-0 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
                </a>
            )}
            {flash?.success && <output className="mt-3 block rounded-2xl border border-emerald-200 bg-emerald-50 text-emerald-900 px-4 py-3 text-sm dark:bg-emerald-900/20 dark:border-emerald-800 dark:text-emerald-200">{flash.success}</output>}
            {flash?.error && <div className="mt-3 rounded-2xl border border-red-200 bg-red-50 text-red-900 px-4 py-3 text-sm dark:bg-red-900/20 dark:border-red-800 dark:text-red-200" role="alert">{flash.error}</div>}
            {flash?.info && <output className="mt-3 block rounded-2xl border border-amber-200 bg-amber-50 text-amber-900 px-4 py-3 text-sm dark:bg-amber-900/20 dark:border-amber-800 dark:text-amber-200">{flash.info}</output>}
        </div>
    );
}
