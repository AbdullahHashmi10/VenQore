import React from 'react';
import { Head, useForm } from '@inertiajs/react';
import OneGlanceLayout from '@/Layouts/OneGlanceLayout';
import StoreTabs from '@/Components/Commerce/StoreTabs';
import { Clock, Coins, CreditCard, MapPin, Save, Store as StoreIcon, Truck } from 'lucide-react';
import { Alert, Button, Card, CardTitle, Field, ImageInput, Switch, inputCls } from '@/Components/Commerce/ui';
import { DAY_LABEL } from '@/lib/commerce';

export default function Settings({ store, countries, cities, warehouses, days, urls }) {
    const { data, setData, post, processing, errors } = useForm({
        display_name: store.display_name || '', slug: store.slug || '', description: store.description || '',
        country_id: store.country_id || '', city_id: store.city_id || '', address_line: store.address_line || '', map_url: store.map_url || '',
        phone: store.phone || '', email: store.email || '',
        opening_hours: Object.fromEntries(days.map((d) => [d, store.opening_hours?.[d] || { open: '', close: '' }])),
        supports_pickup: !!store.supports_pickup, supports_delivery: !!store.supports_delivery,
        delivery_charge: store.delivery_charge ?? 0, delivery_note: store.delivery_note || '', min_order_amount: store.min_order_amount ?? 0,
        warehouse_id: store.warehouse_id || '', pricing_mode: store.pricing_mode || 'same', pricing_percent: store.pricing_percent ?? 0,
        accept_cod: !!store.accept_cod, accept_pickup_payment: !!store.accept_pickup_payment, accept_bank_transfer: !!store.accept_bank_transfer,
        bank_instructions: store.bank_instructions || '', accept_deadline_minutes: store.accept_deadline_minutes || 120, logo: null, banner: null, show_images: store.show_images !== false,
        orders_outside_hours: !!store.orders_outside_hours, announcement: store.announcement || '', prep_minutes: store.prep_minutes || '', delivery_zones: (store.delivery_zones || []).map((z) => ({ name: z.name, fee: z.fee, min_order: z.min_order || 0 })),
    });
    const cityOptions = cities.filter((c) => String(c.country_id) === String(data.country_id));
    const hour = (d, k, v) => setData('opening_hours', { ...data.opening_hours, [d]: { ...data.opening_hours[d], [k]: v } });
    const submit = (e) => { e.preventDefault(); post(urls.settings_save, { forceFormData: true, preserveScroll: true }); };
    const chk = (k, label, desc) => <Switch checked={data[k]} onChange={(v) => setData(k, v)} label={label} desc={desc} />;
    const copyMonday = () => setData('opening_hours', Object.fromEntries(days.map((d) => [d, { ...data.opening_hours[days[0]] }])));
    const SECTIONS = [['profile', 'Public profile', StoreIcon], ['location', 'Location & contact', MapPin], ['hours', 'Opening hours', Clock], ['fulfilment', 'Pickup & delivery', Truck], ['payment', 'Payment & orders', CreditCard], ['pricing', 'Online pricing', Coins]];

    return (
        <OneGlanceLayout title="Online Store" activeMenu="Marketing">
            <Head title="Online Store settings" />
            <StoreTabs active="settings" urls={urls} status={store.status} sub="Your public profile, hours, delivery and payment options" />
            <form onSubmit={submit} className="grid lg:grid-cols-[1fr_15rem] gap-6 items-start pb-24">
              <div className="space-y-5 min-w-0">
                <Card id="profile" className="space-y-4 scroll-mt-24">
                    <CardTitle icon={StoreIcon} title="Public profile" sub="What customers see at the top of your store" />
                    <Field label="Business name shown to customers" error={errors.display_name}><input className={inputCls} value={data.display_name} onChange={(e) => setData('display_name', e.target.value)} required /></Field>
                    <Field label="Store link" error={errors.slug} hint={`/shop/${data.slug || 'your-store'}`}><input className={inputCls} value={data.slug} onChange={(e) => setData('slug', e.target.value.toLowerCase())} required /></Field>
                    <Field label="Short description" error={errors.description}><textarea className={inputCls} rows={3} value={data.description} onChange={(e) => setData('description', e.target.value)} /></Field>
                    <div className="grid sm:grid-cols-[auto_1fr] gap-4 items-start">
                        <ImageInput label="Logo" current={store.logo_url} error={errors.logo} hint="Square, up to 2 MB" accept="image/*" onChange={(f) => setData('logo', f)} />
                        <ImageInput wide label="Banner" current={store.banner_url} error={errors.banner} hint="Wide JPG, PNG or WebP, up to 3 MB" onChange={(f) => setData('banner', f)} />
                    </div>
                    <Field label="Announcement (shown above your catalogue)" error={errors.announcement} hint="e.g. Closed Friday for Eid. Leave empty for none."><input className={inputCls} maxLength={240} value={data.announcement} onChange={(e) => setData('announcement', e.target.value)} /></Field>
                    {chk('show_images', 'Show product photos', 'Turn off for a compact, text-only catalogue.')}
                </Card>

                <Card id="location" className="space-y-4 scroll-mt-24">
                    <CardTitle icon={MapPin} tone="sky" title="Location & contact" sub="Used for the directory and shown to customers" />
                    <div className="grid sm:grid-cols-2 gap-4">
                        <Field label="Country" error={errors.country_id}><select className={inputCls} value={data.country_id} onChange={(e) => { setData((d) => ({ ...d, country_id: e.target.value, city_id: '' })); }}><option value="">Select…</option>{countries.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Field>
                        <Field label="City" error={errors.city_id} hint="Only pilot cities are available for now."><select className={inputCls} value={data.city_id} onChange={(e) => setData('city_id', e.target.value)} disabled={!data.country_id}><option value="">Select…</option>{cityOptions.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Field>
                    </div>
                    <Field label="Address" error={errors.address_line}><input className={inputCls} value={data.address_line} onChange={(e) => setData('address_line', e.target.value)} /></Field>
                    <Field label="Map link (optional)" error={errors.map_url}><input className={inputCls} value={data.map_url} onChange={(e) => setData('map_url', e.target.value)} placeholder="https://maps.google.com/…" /></Field>
                    <div className="grid sm:grid-cols-2 gap-4">
                        <Field label="Phone" error={errors.phone}><input className={inputCls} value={data.phone} onChange={(e) => setData('phone', e.target.value)} /></Field>
                        <Field label="Email (optional)" error={errors.email}><input className={inputCls} value={data.email} onChange={(e) => setData('email', e.target.value)} /></Field>
                    </div>
                </Card>

                <Card id="hours" className="space-y-3 scroll-mt-24">
                    <CardTitle icon={Clock} tone="amber" title="Opening hours" sub="Leave a day blank for closed. A closing time earlier than opening means after midnight."
                        right={<Button variant="ghost" className="!px-2 !py-1 text-xs" onClick={copyMonday}>Copy {DAY_LABEL[days[0]]} to all</Button>} />
                    {days.map((d) => (
                        <div key={d} className="grid grid-cols-[6rem_1fr_1fr_4.5rem] items-center gap-3 text-sm">
                            <span className="font-medium">{DAY_LABEL[d]}</span>
                            <input type="time" className={inputCls} aria-label={`${DAY_LABEL[d]} opens`} value={data.opening_hours[d].open || ''} onChange={(e) => hour(d, 'open', e.target.value)} />
                            <input type="time" className={inputCls} aria-label={`${DAY_LABEL[d]} closes`} value={data.opening_hours[d].close || ''} onChange={(e) => hour(d, 'close', e.target.value)} />
                            <span className={`text-xs font-semibold text-center rounded-full py-0.5 ${data.opening_hours[d].open && data.opening_hours[d].close ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' : 'bg-sunken text-ink-muted'}`}>{data.opening_hours[d].open && data.opening_hours[d].close ? 'Open' : 'Closed'}</span>
                        </div>
                    ))}
                </Card>

                <Card id="fulfilment" className="space-y-4 scroll-mt-24">
                    <CardTitle icon={Truck} tone="violet" title="Pickup & delivery" />
                    <div className="divide-y divide-line">{chk('supports_pickup', 'Customer pickup', 'Customers collect from your address.')}{chk('supports_delivery', 'Delivery by you', 'You deliver; set a flat fee or delivery areas below.')}</div>
                    <div className="grid sm:grid-cols-2 gap-4">
                        <Field label="Flat delivery charge" error={errors.delivery_charge}><input type="number" min="0" step="0.01" className={inputCls} value={data.delivery_charge} onChange={(e) => setData('delivery_charge', e.target.value)} /></Field>
                        <Field label="Minimum order (0 = none)" error={errors.min_order_amount}><input type="number" min="0" step="0.01" className={inputCls} value={data.min_order_amount} onChange={(e) => setData('min_order_amount', e.target.value)} /></Field>
                    </div>
                    <label className="flex items-start gap-2 text-sm rounded-xl bg-sunken p-3"><input type="checkbox" className="mt-1" checked={!!data.orders_outside_hours} onChange={(e) => setData('orders_outside_hours', e.target.checked)} /><span><b>Accept advance orders when closed.</b> Off by default: once you set opening hours, customers cannot place orders outside them.</span></label>
                    <Field label="Usual preparation time in minutes (optional)" error={errors.prep_minutes} hint="Shown to customers as an estimate, never a promise."><input type="number" min="1" max="1440" className={inputCls} value={data.prep_minutes} onChange={(e) => setData('prep_minutes', e.target.value)} /></Field>
                    <div className="space-y-2">
                        <div className="text-sm font-medium">Delivery areas (optional)</div>
                        <p className="text-xs text-ink-muted">If you add areas, customers must pick one. Each area sets its own fee and minimum order, and addresses outside them are not accepted. Leave empty to use the flat charge above.</p>
                        {errors.delivery_zones && <p className="text-xs text-red-600" role="alert">{errors.delivery_zones}</p>}
                        {data.delivery_zones.map((z, i) => (
                            <div key={i} className="grid grid-cols-[1fr_6rem_6rem_auto] gap-2 items-center">
                                <input className={inputCls} placeholder="Area name" aria-label="Area name" maxLength={60} value={z.name} onChange={(e) => setData('delivery_zones', data.delivery_zones.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))} />
                                <input className={inputCls} type="number" min="0" step="0.01" placeholder="Fee" aria-label="Fee" value={z.fee} onChange={(e) => setData('delivery_zones', data.delivery_zones.map((x, j) => (j === i ? { ...x, fee: e.target.value } : x)))} />
                                <input className={inputCls} type="number" min="0" step="0.01" placeholder="Min order" aria-label="Minimum order" value={z.min_order} onChange={(e) => setData('delivery_zones', data.delivery_zones.map((x, j) => (j === i ? { ...x, min_order: e.target.value } : x)))} />
                                <button type="button" className="text-sm underline" onClick={() => setData('delivery_zones', data.delivery_zones.filter((_, j) => j !== i))}>Remove</button>
                            </div>
                        ))}
                        {data.delivery_zones.length < 20 && <Button type="button" variant="secondary" onClick={() => setData('delivery_zones', [...data.delivery_zones, { name: '', fee: 0, min_order: 0 }])}>Add delivery area</Button>}
                    </div>
                    <Field label="Delivery instructions shown to customers" error={errors.delivery_note}><input className={inputCls} value={data.delivery_note} onChange={(e) => setData('delivery_note', e.target.value)} placeholder="e.g. We deliver within 5 km" /></Field>
                </Card>

                <Card id="payment" className="space-y-4 scroll-mt-24">
                    <CardTitle icon={CreditCard} tone="emerald" title="Payment & orders" sub="How customers pay and how long you have to accept" />
                    <div className="divide-y divide-line">{chk('accept_cod', 'Cash on delivery', 'Delivery orders only.')}{chk('accept_pickup_payment', 'Pay at pickup', 'Pickup orders only.')}{chk('accept_bank_transfer', 'Bank transfer', 'Customer reports the transfer; you verify it before marking paid.')}</div>
                    {data.accept_bank_transfer && <Field label="Bank transfer instructions" error={errors.bank_instructions}><textarea className={inputCls} rows={3} value={data.bank_instructions} onChange={(e) => setData('bank_instructions', e.target.value)} /></Field>}
                    <Field label="Fulfilment warehouse" error={errors.warehouse_id} hint="Online orders reserve and deduct stock from this warehouse."><select className={inputCls} value={data.warehouse_id} onChange={(e) => setData('warehouse_id', e.target.value)}><option value="">Select…</option>{warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}</select></Field>
                    <Field label="Minutes to accept an order before it expires" error={errors.accept_deadline_minutes}><input type="number" min="15" max="1440" className={inputCls} value={data.accept_deadline_minutes} onChange={(e) => setData('accept_deadline_minutes', e.target.value)} /></Field>
                </Card>

                <Card id="pricing" className="space-y-4 scroll-mt-24">
                    <CardTitle icon={Coins} tone="rose" title="Online pricing" sub="Applies to products without their own online price. Your regular price never changes." />
                    <div className="grid sm:grid-cols-2 gap-4">
                        <Field label="Default online price" error={errors.pricing_mode}><select className={inputCls} value={data.pricing_mode} onChange={(e) => setData('pricing_mode', e.target.value)}><option value="same">Same as regular price</option><option value="increase">Increase by a percentage</option><option value="decrease">Decrease by a percentage</option></select></Field>
                        {data.pricing_mode !== 'same' && <Field label="Percentage" error={errors.pricing_percent}><input type="number" min="0" step="0.01" className={inputCls} value={data.pricing_percent} onChange={(e) => setData('pricing_percent', e.target.value)} /></Field>}
                    </div>
                    {data.pricing_mode !== 'same' && <Alert kind="info">Example: a Rs 1,000 product shows as Rs {(1000 * (1 + (data.pricing_mode === 'increase' ? 1 : -1) * Number(data.pricing_percent || 0) / 100)).toLocaleString(undefined, { maximumFractionDigits: 2 })} online.</Alert>}
                </Card>

              </div>
              <aside className="hidden lg:block sticky top-24 space-y-3">
                <nav aria-label="Settings sections" className="rounded-2xl border border-line bg-surface p-2">
                    {SECTIONS.map(([id, label, Icon]) => (
                        <a key={id} href={`#${id}`} className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm text-ink-secondary hover:bg-interactive-hover hover:text-ink"><Icon size={15} aria-hidden="true" />{label}</a>
                    ))}
                </nav>
                <div className="rounded-2xl border border-line bg-surface p-4">
                    <div className="flex items-center gap-3">
                        {store.logo_url ? <img src={store.logo_url} alt="" className="h-10 w-10 rounded-xl object-cover" /> : <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-brand-600 text-white font-bold">{(data.display_name || '?').charAt(0).toUpperCase()}</span>}
                        <div className="min-w-0"><div className="font-semibold text-ink truncate">{data.display_name || 'Your business'}</div><div className="text-xs text-ink-muted truncate">/shop/{data.slug || 'your-store'}</div></div>
                    </div>
                    {data.description && <p className="mt-2 text-xs text-ink-muted line-clamp-3">{data.description}</p>}
                </div>
              </aside>
              <div className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface/90 backdrop-blur px-4 py-3 lg:pl-28">
                <div className="mx-auto flex max-w-6xl items-center justify-between gap-3">
                    <span className="text-sm text-ink-muted">{Object.keys(errors).length ? <span className="text-red-600 font-medium">Please fix the highlighted fields.</span> : 'Changes apply to your public store as soon as you save.'}</span>
                    <Button type="submit" disabled={processing}><Save size={16} />{processing ? 'Saving…' : 'Save settings'}</Button>
                </div>
              </div>
            </form>
        </OneGlanceLayout>
    );
}
