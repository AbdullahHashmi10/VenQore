<?php

declare(strict_types=1);

namespace phpseclib4\Exception;

/**
 * Indicates a timeout awaiting server response
 */
class TimeoutException extends \RuntimeException implements BaseException
{
}
