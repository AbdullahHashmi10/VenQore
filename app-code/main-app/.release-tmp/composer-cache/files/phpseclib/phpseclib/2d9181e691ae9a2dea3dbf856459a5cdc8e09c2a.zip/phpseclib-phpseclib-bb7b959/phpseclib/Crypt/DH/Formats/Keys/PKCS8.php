<?php

/**
 * PKCS#8 Formatted DH Key Handler
 *
 * PHP version 8.1+
 *
 * Processes keys with the following headers:
 *
 * -----BEGIN ENCRYPTED PRIVATE KEY-----
 * -----BEGIN PRIVATE KEY-----
 * -----BEGIN PUBLIC KEY-----
 *
 * @author    Jim Wigginton <terrafrost@php.net>
 * @copyright 2016-2026 Jim Wigginton
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      https://phpseclib.com/
 */

declare(strict_types=1);

namespace phpseclib4\Crypt\DH\Formats\Keys;

use phpseclib4\Crypt\Common\Formats\Keys\PKCS8 as Progenitor;
use phpseclib4\Exception\{InvalidArgumentException, UnexpectedValueException};
use phpseclib4\File\ASN1;
use phpseclib4\File\ASN1\Maps;
use phpseclib4\Math\BigInteger;

/**
 * PKCS#8 Formatted DH Key Handler
 *
 * @author  Jim Wigginton <terrafrost@php.net>
 * @psalm-api
 */
abstract class PKCS8 extends Progenitor
{
    /**
     * OID Name
     *
     * @var string
     */
    public const OID_NAME = 'dhKeyAgreement';

    /**
     * OID Value
     *
     * @var string
     */
    public const OID_VALUE = '1.2.840.113549.1.3.1';

    /**
     * Break a public or private key down into its constituent components
     */
    public static function load(
        #[\SensitiveParameter] string $key,
        #[\SensitiveParameter] ?string $password = null
    ): array {
        $isPublic = str_contains($key, 'PUBLIC');

        $key = parent::load($key, $password);

        $type = isset($key['privateKey']) ? 'privateKey' : 'publicKey';

        switch (true) {
            case !$isPublic && $type == 'publicKey':
                throw new UnexpectedValueException('Human readable string claims non-public key but DER encoded string claims public key');
            case $isPublic && $type == 'privateKey':
                throw new UnexpectedValueException('Human readable string claims public key but DER encoded string claims private key');
        }

        $decoded = ASN1::decodeBER($key[$type . 'Algorithm']['parameters']->value);
        $components = ASN1::map($decoded, Maps\DHParameter::MAP)->toArray();

        $decoded = ASN1::decodeBER((string) $key[$type]);
        if (!$decoded['content'] instanceof BigInteger) {
            throw new UnexpectedValueException('Unable to decode BER of parameters');
        }
        $components[$type] = $decoded['content'];

        return $components;
    }

    /**
     * Convert a private key to the appropriate format.
     *
     * @psalm-suppress PossiblyUnusedParam
     */
    public static function savePrivateKey(
        BigInteger $prime,
        BigInteger $base,
        BigInteger $privateKey,
        BigInteger $publicKey,
        #[\SensitiveParameter] ?string $password = null,
        array $options = []
    ): string {
        $params = [
            'prime' => $prime,
            'base' => $base,
        ];
        $params = ASN1::encodeDER($params, Maps\DHParameter::MAP);
        $params = new ASN1\Element($params);
        $key = ASN1::encodeDER($privateKey, ['type' => ASN1::TYPE_INTEGER]);
        return self::wrapPrivateKey(
            key: $key,
            params: $params,
            password: $password,
            options: $options
        );
    }

    /**
     * Convert a public key to the appropriate format
     */
    public static function savePublicKey(BigInteger $prime, BigInteger $base, BigInteger $publicKey, array $options = []): string
    {
        $params = [
            'prime' => $prime,
            'base' => $base,
        ];
        $params = ASN1::encodeDER($params, Maps\DHParameter::MAP);
        $params = new ASN1\Element($params);
        $key = ASN1::encodeDER($publicKey, ['type' => ASN1::TYPE_INTEGER]);
        return self::wrapPublicKey(
            key: $key,
            params: $params,
            options: $options
        );
    }
}
