<?php

/**
 * PKCS8ShroudedKeyBag
 *
 * PHP version 8.1+
 *
 * @author    Jim Wigginton <terrafrost@php.net>
 * @copyright 2015-2026 Jim Wigginton
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      https://phpseclib.com/
 */

declare(strict_types=1);

namespace phpseclib4\File\ASN1\Maps;

/**
 * PKCS8ShroudedKeyBag
 *
 * @author  Jim Wigginton <terrafrost@php.net>
 */
abstract class PKCS8ShroudedKeyBag
{
    public const MAP = EncryptedPrivateKeyInfo::MAP;
}
